import os
print("Malicious file executed")